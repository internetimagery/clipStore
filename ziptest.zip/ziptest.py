# Testing zipfile functionality

import zipfile

print "hello"
